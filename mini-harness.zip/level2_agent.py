"""
LEVEL 2 — 일하는 에이전트 (도구 4개 + 검증 게이트)
================================================================
Level 1에 세 가지가 추가된다.

  1) 쓰는 손      : write_file, run_bash  → 실제로 코드를 고칠 수 있다
  2) 샌드박스     : 임시 폴더 격리 + 위험 명령 차단
  3) 검증 게이트  : 모델이 "다 했다"고 해도 하네스가 직접 테스트를 돌려서 확인한다.
                    실패하면 그 실패 메시지를 그대로 되돌려 보내 다시 시킨다.

3번이 핵심이다. 모델의 자기 보고를 믿지 않고 기계적으로 확인하는 이 루프가
없으면 "고쳤습니다"라는 거짓 성공이 그대로 최종 결과가 된다.

실행:  python level2_agent.py            (가짜 모델)
       python level2_agent.py --real     (실제 API)
"""

import sys
from pathlib import Path

from model import AnthropicModel, FakeModel, Reply, ToolCall, assistant_message, tool_result_message
from tools import Sandbox, fresh_workdir, make_tools

SYSTEM = """당신은 파이썬 개발자입니다. 주어진 도구만으로 작업하세요.
규칙:
- 추측하지 말고 반드시 파일을 읽어서 확인하세요.
- 고치기 전에 먼저 `python3 -m unittest -q` 를 돌려 실패를 직접 확인하세요.
- 부분 수정에는 edit_file 을 쓰세요. write_file 은 파일 전체를 덮어쓰므로
  쓸 때는 반드시 완성된 전체 내용을 넘기세요.
- 수정 후 다시 테스트를 돌려 통과를 확인한 뒤에 마치세요."""

VERIFY_CMD = "python3 -m unittest -q"


def run_agent(model, task: str, workdir: Path, max_steps: int = 20, max_verify: int = 3):
    sandbox = Sandbox(workdir)
    tools = {t.name: t for t in make_tools(sandbox)}
    messages = [{"role": "user", "content": task}]
    verify_rounds = 0
    step = 0

    while step < max_steps:
        step += 1
        reply = model.call(messages, tools=list(tools.values()))
        messages.append(assistant_message(reply))

        if reply.text:
            print(f"\n\033[36m[{step}] 모델\033[0m {reply.text}")

        # ── 모델이 도구를 부르지 않았다 = 스스로 끝났다고 판단했다
        if not reply.wants_tools:
            # verify_rounds 는 일부러 리셋하지 않는다. '검증 실패 총 횟수'에
            # 하드 상한을 두는 편이, 도구를 조금씩 부르며 무한히 버티는
            # 패턴을 막는 데 안전하다.
            verify_rounds += 1
            ok, out = verify(sandbox)
            if ok:
                print(f"\n\033[32m✅ 검증 통과\033[0m (모델 호출 {step}회)")
                return True, messages
            if verify_rounds >= max_verify:
                print(f"\n\033[31m❌ 검증 실패 — 재시도 한도({max_verify}) 초과\033[0m")
                return False, messages
            # 실패를 모델에게 그대로 되먹임한다. 이게 자기수정의 연료다.
            print(f"\n\033[33m⟳ 검증 실패 → 모델에게 되돌려 보냄 ({verify_rounds}/{max_verify})\033[0m")
            messages.append({"role": "user", "content":
                f"아직 테스트가 실패합니다. `{VERIFY_CMD}` 결과:\n\n{out}\n\n원인을 다시 찾아 고치세요."})
            continue

        # ── 도구 실행
        results = []
        for call in reply.tool_calls:
            preview = {k: (v[:60] + "…" if isinstance(v, str) and len(v) > 60 else v)
                       for k, v in call.args.items()}
            print(f"\033[90m[{step}] 🔧 {call.name} {preview}\033[0m")
            # ★ 도구 조회와 도구 실행을 같은 try 에 넣으면 안 된다.
            #   도구 '안에서' 난 KeyError 가 "없는 도구입니다"로 오보된다.
            tool = tools.get(call.name)
            if tool is None:
                out, err = f"없는 도구입니다: {call.name}. 사용 가능: {', '.join(tools)}", True
            else:
                try:
                    out, err = str(tool.run(**call.args)), False
                except Exception as e:
                    out, err = f"{type(e).__name__}: {e}", True
            if err:
                print(f"\033[31m      ↳ {out}\033[0m")
            results.append((call.id, out[:6000], err))  # 결과는 잘라서 넣는다(컨텍스트 보호)

        messages.append(tool_result_message(results))

    print(f"\n\033[31m❌ 최대 스텝({max_steps}) 초과\033[0m")
    return False, messages


def verify(sandbox: Sandbox):
    """하네스가 직접 돌리는 검증. 모델의 말이 아니라 종료 코드를 믿는다."""
    import subprocess
    try:
        r = subprocess.run(VERIFY_CMD, shell=True, cwd=sandbox.root,
                           capture_output=True, text=True, timeout=60)
    except subprocess.TimeoutExpired:
        # ★ 여기를 안 감싸면, 에이전트가 무한루프 테스트를 써넣는 순간
        #   하네스 자체가 죽는다. 검증기는 절대 예외를 밖으로 흘리지 않는다.
        return False, "검증 명령이 60초 안에 끝나지 않았습니다(무한 루프 의심)."
    return r.returncode == 0, (r.stdout + r.stderr).strip()


# ──────────────────────────────────────────────────────────────
# 가짜 모델 시나리오
#   일부러 '절반만 고치는' 실수를 넣었다. 검증 게이트가 그걸 잡아내고
#   두 번째 시도에서 완전히 고치는 과정을 볼 수 있다.
# ──────────────────────────────────────────────────────────────
HALF_FIX = '''"""에이전트가 고쳐야 할 대상 코드."""


def average(nums):
    if not nums:
        return 0
    return sum(nums) / len(nums)


def percent(part, whole):
    return part / whole * 100
'''

FULL_FIX = '''"""에이전트가 고쳐야 할 대상 코드."""


def average(nums):
    if not nums:
        return 0
    return sum(nums) / len(nums)


def percent(part, whole):
    if whole == 0:
        return 0
    return part / whole * 100
'''

SCRIPT = [
    Reply(text="먼저 폴더 구조를 봅니다.",
          tool_calls=[ToolCall("a1", "list_dir", {"path": "."})]),
    Reply(text="테스트를 돌려 실패를 직접 확인합니다.",
          tool_calls=[ToolCall("a2", "run_bash", {"command": "python3 -m unittest -q"})]),
    Reply(text="구현 코드를 읽습니다.",
          tool_calls=[ToolCall("a3", "read_file", {"path": "calc.py"})]),
    Reply(text="average() 의 빈 리스트 처리를 추가합니다.",
          tool_calls=[ToolCall("a4", "write_file", {"path": "calc.py", "content": HALF_FIX})]),
    Reply(text="고쳤습니다. 완료했습니다."),          # ← 거짓 성공 선언. 검증 게이트가 잡는다.
    Reply(text="percent() 도 같은 문제였네요. 함께 고칩니다.",
          tool_calls=[ToolCall("a5", "write_file", {"path": "calc.py", "content": FULL_FIX})]),
    Reply(text="테스트를 다시 돌립니다.",
          tool_calls=[ToolCall("a6", "run_bash", {"command": "python3 -m unittest -q"})]),
    Reply(text="4개 테스트 모두 통과했습니다."),
    # 위험한 명령을 시도하는 경우도 넣어두면 샌드박스 동작을 볼 수 있다
]

TASK = "테스트가 실패합니다. 원인을 찾아 코드를 고치고, 테스트가 통과하는지 확인하세요."

if __name__ == "__main__":
    workdir = fresh_workdir(Path(__file__).parent / "demo_project")
    print(f"작업 폴더(임시 복사본): {workdir}\n원본 demo_project 는 건드리지 않습니다.")

    model = (AnthropicModel(system=SYSTEM) if "--real" in sys.argv else FakeModel(SCRIPT))
    ok, messages = run_agent(model, TASK, workdir)

    print(f"\n최종 결과: {'성공' if ok else '실패'}")
    print(f"대화에 쌓인 메시지 수: {len(messages)}   ← 이게 컨텍스트다. Level 3의 관리 대상.")
    print(f"고쳐진 파일 확인:  cat {workdir}/calc.py")
