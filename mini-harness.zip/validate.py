"""
validate.py — 하네스 자체를 검증하는 하네스
================================================================
"검증 없는 하네스는 신뢰할 수 없다"는 원칙을 이 레포 자신에게 적용한다.
여기서 검사하는 것은 하네스가 만들어내는 **대화 히스토리가 실제 API에
유효한 모양인가**, 그리고 **샌드박스가 실제로 가두는가**다.

실행:  python3 validate.py
"""

import itertools
import subprocess
import sys
import tempfile
from pathlib import Path

from level3_production import Budget, Harness, est_tokens, make_subagent_tool, verify_tests
from level3_production import MAIN_SCRIPT, SUB_SCRIPT, TASK
from model import FakeModel, Reply, assistant_message, tool_result_message
from tools import Sandbox, fresh_workdir

FAILS = []


def check(cond, label, detail=""):
    print(f"  {'✅' if cond else '❌'} {label}" + (f" — {detail}" if detail and not cond else ""))
    if not cond:
        FAILS.append(label)


def blocks(msg, t):
    c = msg.get("content")
    if not isinstance(c, list):
        return []
    return [b for b in c if isinstance(b, dict) and b.get("type") == t]


# ──────────────────────────────────────────────────────────────
def validate_history(messages, label):
    """실제 Anthropic API가 강제하는 불변식들을 확인한다."""
    ok = True

    if not messages or messages[0].get("role") != "user":
        check(False, f"{label}: 첫 메시지는 user")
        ok = False

    for i, m in enumerate(messages):
        c = m.get("content")
        if c == [] or c == "":
            check(False, f"{label}: 빈 content (idx {i})")
            ok = False
        for b in (c if isinstance(c, list) else []):
            if isinstance(b, dict) and b.get("type") == "tool_result" and not b.get("content"):
                check(False, f"{label}: 빈 tool_result content (idx {i})")
                ok = False

    # tool_use 하나하나는 '바로 다음' 메시지에 같은 id의 tool_result 가 있어야 한다
    for i, m in enumerate(messages):
        ids = {b["id"] for b in blocks(m, "tool_use")}
        if not ids:
            continue
        nxt = messages[i + 1] if i + 1 < len(messages) else {}
        answered = {b["tool_use_id"] for b in blocks(nxt, "tool_result")}
        if ids - answered:
            check(False, f"{label}: 응답 없는 tool_use {ids - answered} (idx {i})")
            ok = False

    # 고아 tool_result (짝인 tool_use 가 앞에 없음)
    for i, m in enumerate(messages):
        got = {b["tool_use_id"] for b in blocks(m, "tool_result")}
        if not got:
            continue
        prev = messages[i - 1] if i else {}
        avail = {b["id"] for b in blocks(prev, "tool_use")}
        if got - avail:
            check(False, f"{label}: 고아 tool_result {got - avail} (idx {i})")
            ok = False

    # 같은 역할이 연속되는 모양 (직접 API는 병합하지만 엄격한 검증기는 거절)
    for i in range(1, len(messages)):
        if messages[i].get("role") == messages[i - 1].get("role"):
            check(False, f"{label}: 연속 {messages[i]['role']} 턴 (idx {i})")
            ok = False

    if ok:
        check(True, f"{label}: 히스토리 {len(messages)}개 메시지 모두 유효")
    return ok


# ──────────────────────────────────────────────────────────────
print("\n[1] 샌드박스 격리 — 파일 도구")
root = Path(tempfile.mkdtemp()) / "proj"
root.mkdir(parents=True)
(root.parent / "proj_secret").mkdir()
(root.parent / "proj_secret" / "leak.txt").write_text("SECRET", encoding="utf-8")
(root / "ok.txt").write_text("fine", encoding="utf-8")
sb = Sandbox(root)

try:
    sb.resolve("ok.txt")
    check(True, "정상 경로는 통과")
except PermissionError:
    check(False, "정상 경로는 통과")

for bad in ["../proj_secret/leak.txt",      # ★ startswith 버그가 있으면 여기서 뚫린다
            "../../etc/passwd", "/etc/passwd", "sub/../../proj_secret/leak.txt"]:
    try:
        sb.resolve(bad)
        check(False, f"탈출 차단: {bad}", "통과되어 버렸다")
    except PermissionError:
        check(True, f"탈출 차단: {bad}")

print("\n[2] 위험 명령 차단 (deny-list, 근본적으로 불완전함을 전제)")
for cmd in ["rm -rf .", "rm --recursive --force x", "cat ../proj_secret/leak.txt",
            "find . -delete"]:
    try:
        sb.check_command(cmd)
        check(False, f"차단: {cmd!r}", "통과되어 버렸다")
    except PermissionError:
        check(True, f"차단: {cmd!r}")
try:
    sb.check_command("python3 -m unittest -q")
    check(True, "정상 명령은 통과")
except PermissionError:
    check(False, "정상 명령은 통과")

print("\n[3] 메시지 변환 — 빈 값이 API 거절 모양을 만들지 않는지")
check(assistant_message(Reply())["content"] != [], "빈 Reply → 빈 content 아님")
check(tool_result_message([("t1", "", False)])["content"][0]["content"] != "",
      "빈 도구 출력 → 빈 tool_result content 아님")
check("is_error" not in tool_result_message([("t1", "ok", False)])["content"][0],
      "성공 시 is_error 키 없음")
check(tool_result_message([("t1", "boom", True)])["content"][0]["is_error"] is True,
      "실패 시 is_error=True")

print("\n[4] 정상 실행 후 히스토리 유효성 (압축 없음)")
wd = fresh_workdir(Path(__file__).parent / "demo_project")
h = Harness(FakeModel(list(MAIN_SCRIPT)), wd, label="t", budget=Budget(80),
            compact_at=10_000, retry_sleep=0)
h.tools["spawn_subagent"] = make_subagent_tool(h, lambda p: FakeModel(list(SUB_SCRIPT)))
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()):
    ok, _ = h.run(TASK, verify_fn=verify_tests)
check(ok, "압축 없이 작업 성공")
validate_history(h.messages, "무압축")

print("\n[5] 압축 스트레스 — keep_tail 을 홀짝/경계로 흔들어도 짝이 안 깨지는가")
#     ★ 이게 이 레포에서 가장 미묘한 버그가 숨는 자리다.
#       tail 을 그냥 messages[-N:] 으로 자르면 N이 홀수일 때
#       tool_result 로 시작하는 구간이 남아 실제 API에서 400 이 난다.
bad = []
for keep_tail, compact_at in itertools.product([2, 3, 4, 5, 6, 7, 8, 9], [4, 5, 6, 7, 10, 12]):
    if compact_at <= keep_tail:
        continue
    wd2 = fresh_workdir(Path(__file__).parent / "demo_project")
    hh = Harness(FakeModel(list(MAIN_SCRIPT)), wd2, label="s", budget=Budget(200),
                 compact_at=compact_at, keep_tail=keep_tail, retry_sleep=0)
    hh.tools["spawn_subagent"] = make_subagent_tool(hh, lambda p: FakeModel(list(SUB_SCRIPT)))
    with contextlib.redirect_stdout(io.StringIO()):
        okk, _ = hh.run(TASK, verify_fn=verify_tests)
        before = list(FAILS)
        valid = validate_history(hh.messages, f"kt={keep_tail},ca={compact_at}")
        del FAILS[len(before):]          # 개별 실패는 여기서 집계만 하고 되돌린다
    if not (okk and valid):
        bad.append((keep_tail, compact_at))
check(not bad, f"압축 조합 전수 검사 ({len(bad)}개 실패)", str(bad[:5]))

print("\n[6] 예산 — 재시도가 예산을 빠져나가지 않는가")
wd3 = fresh_workdir(Path(__file__).parent / "demo_project")
b = Budget(max_requests=100)
hb = Harness(FakeModel(list(MAIN_SCRIPT), flaky_at={1, 2}, flaky_times=2), wd3,
             label="b", budget=b, retry_sleep=0)
hb.tools["spawn_subagent"] = make_subagent_tool(hb, lambda p: FakeModel(list(SUB_SCRIPT)))
with contextlib.redirect_stdout(io.StringIO()):
    hb.run(TASK, verify_fn=verify_tests)
check(b.requests > hb.turns, f"실제 요청({b.requests}) > 루프 턴({hb.turns}) — 재시도가 계상됨")

print("\n[7] 예산 소진 시 폭주하지 않고 멈추는가")
wd4 = fresh_workdir(Path(__file__).parent / "demo_project")
tiny = Budget(max_requests=3)
ht = Harness(FakeModel(list(MAIN_SCRIPT)), wd4, label="x", budget=tiny, retry_sleep=0)
ht.tools["spawn_subagent"] = make_subagent_tool(ht, lambda p: FakeModel(list(SUB_SCRIPT)))
with contextlib.redirect_stdout(io.StringIO()):
    okx, msgx = ht.run(TASK, verify_fn=verify_tests)
check((not okx) and tiny.requests <= 3, f"예산 3회에서 정지 (요청 {tiny.requests}회)", msgx)

print("\n[8] 서브 에이전트가 부모 예산을 공유하는가")
wd5 = fresh_workdir(Path(__file__).parent / "demo_project")
shared = Budget(max_requests=100)
hs = Harness(FakeModel(list(MAIN_SCRIPT)), wd5, label="p", budget=shared, retry_sleep=0)
hs.tools["spawn_subagent"] = make_subagent_tool(hs, lambda p: FakeModel(list(SUB_SCRIPT)))
with contextlib.redirect_stdout(io.StringIO()):
    hs.run(TASK, verify_fn=verify_tests)
check(shared.requests > hs.turns, f"부모 턴 {hs.turns} < 공유 예산 요청 {shared.requests} (서브 포함)")

print("\n[9] 토큰 추정 — 한글을 4배 과소평가하지 않는가")
kor = [{"role": "user", "content": "한" * 1000}]
eng = [{"role": "user", "content": "a" * 1000}]
check(est_tokens(kor) > est_tokens(eng) * 2,
      f"한글 {est_tokens(kor)} > 영문 {est_tokens(eng)} × 2")

print("\n[10] 데모 프로젝트 원본이 그대로인가 (재현성)")
r = subprocess.run("python3 -m unittest -q", shell=True, capture_output=True, text=True,
                   cwd=Path(__file__).parent / "demo_project")
check(r.returncode != 0, "원본 demo_project 는 여전히 실패 상태")

print("\n" + "=" * 60)
if FAILS:
    print(f"❌ 실패 {len(FAILS)}건:")
    for f in FAILS:
        print("   -", f)
    sys.exit(1)
print("✅ 전부 통과")
