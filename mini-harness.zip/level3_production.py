"""
LEVEL 3 — 실무형 하네스
================================================================
Level 2의 루프에 실제 제품에서 반드시 필요한 것들을 붙인다.

  A. 컨텍스트 압축   : 대화가 길어지면 중간을 요약으로 갈아치운다
                       ★ 이때 tool_use/tool_result 짝을 절대 갈라놓지 않는다
  B. 예산 한도       : 실제 API 요청 수(재시도 포함)에 상한을 둔다
  C. 재시도          : '기다리면 될 수도 있는' 오류만 백오프 후 재시도
  D. 서브 에이전트   : 탐색은 하위 에이전트에게 맡기고 '결론만' 받는다
                       ★ 예산은 부모와 공유한다
  E. 트레이스 로그   : 무슨 도구를 왜 불렀는지 JSONL로 남긴다
  F. 안전            : 파일 도구 경로 격리 + 위험 명령 차단 (tools.py)

실행:  python3 level3_production.py            (가짜 모델, 오프라인)
       python3 level3_production.py --real     (실제 API)
"""

import json
import subprocess
import sys
import time
from pathlib import Path

from model import (AnthropicModel, FakeModel, Reply, ToolCall, assistant_message,
                   is_retryable, tool_result_message)
from tools import Sandbox, Tool, fresh_workdir, make_tools

VERIFY_CMD = "python3 -m unittest -q"


# ──────────────────────────────────────────────────────────────
# 토큰 추정
# ──────────────────────────────────────────────────────────────
def est_tokens(messages) -> int:
    """거친 추정치.

    ★ 주의: 흔히 쓰는 "글자수 / 4" 는 영어·코드에서만 맞는다.
      한글은 대략 글자당 1토큰에 가까우므로 한글 프롬프트에서 /4 를 쓰면
      실제의 1/4 로 과소평가되어 토큰 가드가 사실상 작동하지 않는다.
      그래서 ASCII와 비ASCII를 나눠 센다.
      시스템 프롬프트·도구 스키마·응답은 여기 포함되지 않으니 여전히 하한선이다.
      실무에서는 응답의 usage 값(Reply.usage)을 누적해서 쓰는 것이 정답이다.
    """
    s = json.dumps(messages, ensure_ascii=False)
    ascii_n = sum(1 for ch in s if ord(ch) < 128)
    return ascii_n // 4 + (len(s) - ascii_n)


# ──────────────────────────────────────────────────────────────
# B. 예산 — 부모와 자식이 '같은 객체'를 공유하는 것이 핵심
# ──────────────────────────────────────────────────────────────
class Budget:
    """★ 서브 에이전트에게 별도 예산을 주면 총액 통제가 사라진다.
    (부모 25회 × 자식 8회 = 최악 200회) 그래서 객체 하나를 물려준다.
    또 '루프 반복 횟수'가 아니라 '실제 API 요청 횟수'를 센다 —
    재시도 3회는 청구서에 3번 찍히기 때문이다.
    """

    def __init__(self, max_requests: int = 40, max_context_tokens: int = 40_000):
        self.max_requests = max_requests
        self.max_context_tokens = max_context_tokens
        self.requests = 0          # 재시도까지 포함한 실제 요청 수
        self.tokens_in = 0         # 실제 usage 누적 (real 모드에서만 채워진다)
        self.tokens_out = 0

    def charge_request(self):
        self.requests += 1

    @property
    def exhausted(self) -> bool:
        return self.requests >= self.max_requests

    def note_usage(self, usage):
        if usage:
            self.tokens_in += usage.get("input", 0)
            self.tokens_out += usage.get("output", 0)

    def summary(self) -> str:
        s = f"API 요청 {self.requests}/{self.max_requests}회"
        if self.tokens_in or self.tokens_out:
            s += f" · 실제 토큰 in {self.tokens_in} / out {self.tokens_out}"
        return s


# ──────────────────────────────────────────────────────────────
# 메시지 블록 헬퍼 (압축의 정확성이 여기에 달려 있다)
# ──────────────────────────────────────────────────────────────
def has_block(msg, block_type: str) -> bool:
    c = msg.get("content")
    if not isinstance(c, list):
        return False
    return any(getattr(b, "type", None) == block_type
               or (isinstance(b, dict) and b.get("type") == block_type) for b in c)


def plain_text(msg) -> str:
    c = msg.get("content")
    if isinstance(c, str):
        return c
    if isinstance(c, list):
        return " ".join(b.get("text", "") for b in c
                        if isinstance(b, dict) and b.get("type") == "text")
    return ""


class Harness:
    def __init__(self, model, workdir: Path, *, system="", label="main",
                 budget=None, compact_at=14, keep_tail=8,
                 extra_tools=None, trace=None, retries=3, retry_sleep=1.0):
        self.model = model
        self.sandbox = Sandbox(workdir)
        self.tools = {t.name: t for t in make_tools(self.sandbox)}
        for t in (extra_tools or []):
            self.tools[t.name] = t
        self.system = system                 # ★ 컨텍스트 구성은 하네스의 책임이다
        self.label = label
        self.budget = budget or Budget()
        # ★ 압축 주기 = compact_at - keep_tail. 이 간격이 너무 좁으면
        #   두세 턴마다 압축이 터지면서(thrashing) 방금 읽은 파일 내용이
        #   결론을 내기 직전에 사라진다. 간격은 최소 몇 턴은 되게 잡는다.
        self.compact_at = compact_at         # 이 개수를 넘으면 압축
        self.keep_tail = keep_tail           # 압축 후 남길 최근 메시지 수
        self.retries = max(1, retries)
        self.retry_sleep = retry_sleep       # 데모에서 짧게 줄이기 위한 계수
        self.messages = []
        self.turns = 0                       # 루프 반복 횟수(≠ API 요청 수)
        self.trace = trace if trace is not None else []
        self.task = ""
        self.summary = ""                    # 누적 요약 (압축 때마다 덧붙는다)

    # ── E. 트레이스 ────────────────────────────────────────────
    def log(self, kind, **kw):
        self.trace.append({"agent": self.label, "turn": self.turns, "kind": kind, **kw})

    # ── A. 컨텍스트 압축 ──────────────────────────────────────
    def compact(self):
        """중간을 요약으로 대체한다. 세 가지를 반드시 지킨다.

        1) tool_use / tool_result 짝을 갈라놓지 않는다.
           남길 구간이 tool_result 로 시작하면 그 짝인 tool_use 가 이미
           잘려나간 상태다 → 실제 API에서 400
           ("tool_result block missing corresponding tool_use").
           그래서 짝이 맞을 때까지 시작점을 앞으로 민다.
        2) 요약을 별도 user 메시지로 끼우지 않고 최초 지시 안에 접어 넣는다.
           (user 턴이 연속되는 모양은 엄격한 검증기에서 문제가 된다)
        3) 요약은 누적한다. 이전 요약을 버리면 압축이 반복될수록
           초반 정보가 영구히 사라진다.
        """
        if len(self.messages) <= self.keep_tail + 1:
            return False

        start = len(self.messages) - self.keep_tail
        # (1) 고아 tool_result 로 시작하지 않도록 시작점을 뒤로 민다
        while start < len(self.messages) and has_block(self.messages[start], "tool_result"):
            start += 1
        # user 로 시작하면 head(user)와 연속되므로, 그 내용은 요약으로 흡수한다
        carried = []
        while start < len(self.messages) and self.messages[start].get("role") == "user":
            t = plain_text(self.messages[start])
            if t:
                carried.append(t)
            start += 1

        tail = self.messages[start:]
        # 응답 없는 tool_use 로 끝나면 잘라낸다 (반대 방향의 같은 위반)
        while tail and has_block(tail[-1], "tool_use") and not has_block(tail[-1], "tool_result"):
            if len(tail) == 1:
                tail = []
                break
            tail = tail[:-1]

        dropped = self.messages[1:start]
        if not dropped or not tail:
            return False

        used = []
        for m in dropped:
            c = m.get("content")
            if isinstance(c, list):
                for b in c:
                    name = b.get("name") if isinstance(b, dict) else getattr(b, "name", None)
                    btype = b.get("type") if isinstance(b, dict) else getattr(b, "type", None)
                    if btype == "tool_use" and name:
                        used.append(name)

        # (3) 누적 요약
        piece = f"- 생략된 메시지 {len(dropped)}개 / 도구: {' → '.join(used) or '없음'}"
        if carried:
            piece += "\n- 그 사이 받은 지시/피드백: " + " | ".join(c[:200] for c in carried)
        self.summary = (self.summary + "\n" + piece).strip()

        # (2) 요약을 최초 지시에 접어 넣은 단일 user 메시지로 head 를 재구성
        head = {"role": "user", "content":
                f"{self.task}\n\n[지금까지의 경과 요약]\n{self.summary}"}
        self.messages = [head] + tail

        self.log("compact", dropped=len(dropped), kept=len(tail))
        print(f"\033[35m  ⤵ [{self.label}] 압축: {len(dropped)}개 → 요약, 최근 {len(tail)}개 유지"
              f" (다음 압축까지 {self.compact_at - len(tail) - 1}개 여유)\033[0m")
        return True

    # ── C. 재시도 ─────────────────────────────────────────────
    def call_model(self):
        """★ 예산은 여기서 깎는다. 루프 밖에서 세면 재시도가 예산을 빠져나간다."""
        last = None
        for attempt in range(1, self.retries + 1):
            if self.budget.exhausted:
                raise RuntimeError(f"예산 소진: {self.budget.summary()}")
            self.budget.charge_request()
            try:
                reply = self.model.call(self.messages, list(self.tools.values()),
                                        system=self.system or None)
                self.budget.note_usage(reply.usage)
                return reply
            except Exception as e:
                last = e
                if attempt == self.retries or not is_retryable(e):
                    raise                     # ★ 400/401/TypeError 는 재시도해도 안 낫는다
                wait = (2 ** (attempt - 1)) * self.retry_sleep
                print(f"\033[33m  ↻ 일시적 오류({e}) — {wait:.1f}초 후 재시도 "
                      f"{attempt}/{self.retries - 1}\033[0m")
                self.log("retry", attempt=attempt, error=str(e), wait=wait)
                time.sleep(wait)
        raise last if last else RuntimeError("재시도 실패")

    # ── 메인 루프 ─────────────────────────────────────────────
    def run(self, task: str, verify_fn=None, max_verify=3):
        self.task = task
        self.messages = [{"role": "user", "content": task}]
        verify_rounds = 0

        while True:
            if self.budget.exhausted:
                self.log("stop", reason="budget")
                return False, f"예산 소진 ({self.budget.summary()})"

            # A. 길이/토큰 기반 압축
            if len(self.messages) > self.compact_at or \
               est_tokens(self.messages) > self.budget.max_context_tokens:
                if not self.compact() and est_tokens(self.messages) > self.budget.max_context_tokens:
                    self.log("stop", reason="context")
                    return False, "컨텍스트 한도 초과 (더 줄일 수 없음)"

            self.turns += 1
            reply = self.call_model()
            self.messages.append(assistant_message(reply))
            if reply.text:
                print(f"\033[36m[{self.label} {self.turns}] \033[0m{reply.text}")
                self.log("say", text=reply.text[:200])

            if not reply.wants_tools:
                if verify_fn is None:
                    return True, reply.text
                verify_rounds += 1
                ok, out = verify_fn(self.sandbox)
                self.log("verify", ok=ok)
                if ok:
                    return True, reply.text
                if verify_rounds >= max_verify:
                    return False, "검증 재시도 한도 초과"
                print(f"\033[33m  ⟳ 검증 실패 → 되돌려 보냄 ({verify_rounds}/{max_verify})\033[0m")
                self.messages.append({"role": "user", "content":
                    f"테스트가 아직 실패합니다:\n{out}\n원인을 다시 찾아 고치세요."})
                continue

            results = []
            for c in reply.tool_calls:
                preview = {k: (str(v)[:50] + "…" if len(str(v)) > 50 else v)
                           for k, v in c.args.items()}
                print(f"\033[90m[{self.label} {self.turns}] 🔧 {c.name} {preview}\033[0m")
                tool = self.tools.get(c.name)      # 조회와 실행을 분리 (오보 방지)
                if tool is None:
                    out, err = f"없는 도구: {c.name}. 사용 가능: {', '.join(self.tools)}", True
                else:
                    try:
                        out, err = str(tool.run(**c.args)), False
                    except Exception as e:
                        out, err = f"{type(e).__name__}: {e}", True
                if err:
                    print(f"\033[31m      ↳ 차단/실패: {out}\033[0m")
                # 트레이스에도 잘림을 적용한다. write_file 인자를 통째로 남기면
                # 로그가 소스코드 덤프가 된다.
                self.log("tool", name=c.name,
                         args={k: str(v)[:120] for k, v in c.args.items()},
                         error=err, out=out[:300])
                results.append((c.id, out, err))
            self.messages.append(tool_result_message(results))

    def dump_trace(self, path: Path):
        with open(path, "w", encoding="utf-8") as f:
            for row in self.trace:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        print(f"트레이스 저장: {path} ({len(self.trace)}줄)")


# ── D. 서브 에이전트 ──────────────────────────────────────────
def make_subagent_tool(parent: "Harness", sub_model_factory, sub_system=""):
    """서브 에이전트는 '컨텍스트 방화벽'이다.

    파일 20개를 뒤지는 일을 본체가 직접 하면 대화가 파일 내용으로 가득 찬다.
    하위 에이전트에게 시키면 그 쓰레기는 하위 대화에서 소각되고,
    본체에는 '결론 몇 줄'만 돌아온다. 이게 긴 작업을 가능하게 하는 트릭.

    ★ 예산(budget)과 트레이스(trace)는 부모 것을 그대로 물려준다.
    """

    def _spawn(purpose: str):
        sub = Harness(sub_model_factory(purpose), parent.sandbox.root,
                      system=sub_system, label="sub",
                      budget=parent.budget, trace=parent.trace,
                      compact_at=14, keep_tail=8, retry_sleep=parent.retry_sleep)
        ok, answer = sub.run(f"다음을 조사해서 결론만 간결하게 보고하라: {purpose}")
        return f"[서브 에이전트 보고]\n{answer}" if ok else f"[서브 에이전트 실패] {answer}"

    return Tool("spawn_subagent",
                "조사/탐색 작업을 하위 에이전트에게 위임하고 요약된 결론만 받는다. "
                "파일을 많이 읽어야 하는 조사에 쓴다.",
                {"type": "object",
                 "properties": {"purpose": {"type": "string", "description": "조사할 내용"}},
                 "required": ["purpose"]},
                _spawn)


def verify_tests(sandbox: Sandbox):
    try:
        r = subprocess.run(VERIFY_CMD, shell=True, cwd=sandbox.root,
                           capture_output=True, text=True, timeout=60)
    except subprocess.TimeoutExpired:
        return False, "검증 명령이 60초 안에 끝나지 않았습니다(무한 루프 의심)."
    return r.returncode == 0, (r.stdout + r.stderr).strip()


# ──────────────────────────────────────────────────────────────
# 가짜 시나리오
# ──────────────────────────────────────────────────────────────
MAIN_SYSTEM = """당신은 시니어 파이썬 개발자입니다.
- 조사·탐색이 필요하면 spawn_subagent 로 위임하고 결론만 받으세요.
- 부분 수정에는 edit_file 을 쓰세요(old_string 은 유일해야 합니다).
- 수정 후 `python3 -m unittest -q` 로 반드시 통과를 확인하세요."""

SUB_SYSTEM = "당신은 코드 조사 전문가입니다. 파일을 읽어 원인을 특정하고, 결론만 간결히 보고하세요."

MAIN_SCRIPT = [
    # F. 안전장치 시연 — 파일 도구의 폴더 탈출 시도
    Reply(text="시스템 파일을 먼저 볼까요?",
          tool_calls=[ToolCall("m0", "read_file", {"path": "../../../etc/passwd"})]),
    # F. 안전장치 시연 — 파괴적 명령
    Reply(text="폴더를 정리하겠습니다.",
          tool_calls=[ToolCall("m1", "run_bash", {"command": "rm -rf ."})]),
    # D. 조사는 서브 에이전트에게 위임
    Reply(text="차단되었군요. 정상 경로로 갑니다. 조사는 하위 에이전트에게 맡기겠습니다.",
          tool_calls=[ToolCall("m2", "spawn_subagent",
                               {"purpose": "calc.py 와 test_calc.py 를 읽고 실패 원인을 특정하라"})]),
    # 치환형 편집 — 전체 덮어쓰기보다 안전
    Reply(text="보고를 받았습니다. average() 부터 고칩니다.",
          tool_calls=[ToolCall("m3", "edit_file", {
              "path": "calc.py",
              "old_string": "def average(nums):\n    return sum(nums) / len(nums)",
              "new_string": "def average(nums):\n    if not nums:\n        return 0\n    return sum(nums) / len(nums)"})]),
    Reply(text="검증합니다.",
          tool_calls=[ToolCall("m4", "run_bash", {"command": VERIFY_CMD})]),
    Reply(text="average 는 통과. percent 도 같은 문제라 이어서 고칩니다.",
          tool_calls=[ToolCall("m5", "edit_file", {
              "path": "calc.py",
              "old_string": "def percent(part, whole):\n    return part / whole * 100",
              "new_string": "def percent(part, whole):\n    if whole == 0:\n        return 0\n    return part / whole * 100"})]),
    Reply(text="다시 검증합니다.",
          tool_calls=[ToolCall("m6", "run_bash", {"command": VERIFY_CMD})]),
    Reply(text="4개 테스트 모두 통과. 작업 완료."),
]

SUB_SCRIPT = [
    Reply(text="파일 목록 확인.", tool_calls=[ToolCall("s0", "list_dir", {"path": "."})]),
    Reply(text="테스트 읽기.", tool_calls=[ToolCall("s1", "read_file", {"path": "test_calc.py"})]),
    Reply(text="구현 읽기.", tool_calls=[ToolCall("s2", "read_file", {"path": "calc.py"})]),
    Reply(text="테스트 실행.", tool_calls=[ToolCall("s3", "run_bash", {"command": VERIFY_CMD})]),
    Reply(text="결론: average() 는 빈 리스트, percent() 는 whole==0 에서 ZeroDivisionError. "
               "두 함수 모두 앞단에 0 반환 가드가 필요하다."),
]

TASK = "테스트가 실패합니다. 조사하고 고치고 검증까지 완료하세요."

if __name__ == "__main__":
    real = "--real" in sys.argv
    here = Path(__file__).parent
    workdir = fresh_workdir(here / "demo_project")
    print(f"작업 폴더: {workdir}\n")

    budget = Budget(max_requests=40, max_context_tokens=40_000)

    if real:
        main_model = AnthropicModel()
        sub_factory = lambda purpose: AnthropicModel()
    else:
        # 3번째 호출에서 일부러 일시적 오류를 2번 내서 재시도 로직을 눈으로 확인한다
        main_model = FakeModel(MAIN_SCRIPT, flaky_at={3}, flaky_times=2)
        sub_factory = lambda purpose: FakeModel(SUB_SCRIPT)

    # 압축을 눈으로 보려고 일부러 낮게 잡았다(간격 3메시지 ≈ 1.5턴 — 실무에선 너무 좁다).
    # 실제로 쓸 때는 컨텍스트 한도의 60~70% 지점에서 토큰 기준으로 트리거하는 편이 낫다.
    h = Harness(main_model, workdir, system=MAIN_SYSTEM, label="main",
                budget=budget, compact_at=10, keep_tail=6,
                retry_sleep=0.05 if not real else 1.0)
    h.tools["spawn_subagent"] = make_subagent_tool(h, sub_factory, sub_system=SUB_SYSTEM)

    ok, msg = h.run(TASK, verify_fn=verify_tests)

    verdict = "\033[32m✅ 성공" if ok else "\033[31m❌ 실패"
    print(f"\n{verdict}\033[0m — {msg}")
    print(f"{budget.summary()}")
    print(f"루프 턴: main {h.turns}회 / 최종 컨텍스트 {len(h.messages)}개 메시지 "
          f"(≈{est_tokens(h.messages)} 토큰, 누적 소비량이 아니라 '현재 크기')")
    h.dump_trace(here / "trace.jsonl")
